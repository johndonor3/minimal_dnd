#!/usr/bin/python
# import asyncio


def getTemplateDictBase():
    version = "current"
    return {
            "foo": "bar"
    }